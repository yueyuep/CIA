/**
 * Create by yueyue on 2021/1/8
 */
public class Main {
    public static void main(String[] args) {

        System.out.printf("newversion");
        int a = 2;
        double area = Math.PI * Math.pow(a, 2);

    }
}
